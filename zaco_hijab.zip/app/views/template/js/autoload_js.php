<!-- JS -->
	<!-- Bootstrap 3.3.6 -->
	<script src="<?= base_url."assets/bootstrap/js/bootstrap.min.js"; ?>"></script>
	<!-- SlimScroll -->
	<script src="<?= base_url."assets/plugins/slimScroll/jquery.slimscroll.min.js"; ?>"></script>
	<!-- FastClick -->
	<script src="<?= base_url."assets/plugins/fastclick/fastclick.js"; ?>"></script>
	<!-- AdminLTE App -->
	<script src="<?= base_url."assets/dist/js/app.min.js"; ?>"></script>
	<!-- AdminLTE for demo purposes -->
	<script src="<?= base_url."assets/dist/js/demo.js"; ?>"></script>
	<script type="text/javascript" src="<?= base_url."assets/plugins/sweet-alert/sweet-alert.min.js"; ?>"></script>
 	<script type="text/javascript" src="<?= base_url."assets/plugins/alertifyjs/alertify.min.js"; ?>"></script>
 	<script type="text/javascript" src="<?= base_url."assets/plugins/blockUI/jquery.blockUI.js"; ?>"></script>
<!-- end JS -->