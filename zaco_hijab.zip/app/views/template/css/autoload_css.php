	<!-- CSS -->

		<!-- Bootstrap 3.3.6 -->
		<link rel="stylesheet" href="<?= base_url."assets/bootstrap/css/bootstrap.min.css"; ?>">
		<!-- font awesome -->
		<link rel="stylesheet" type="text/css" href="<?= base_url."assets/plugins/font-awesome-4.7.0/css/font-awesome.min.css"; ?>">
		<!-- Ionicons -->
		<link rel="stylesheet" href="<?= base_url."assets/plugins/ionicons-2.0.1/css/ionicons.min.css"; ?>">
		<!-- Select2 -->
  		<link rel="stylesheet" href="<?= base_url."assets/plugins/select2/select2.min.css"; ?>">
		<!-- Theme style -->
		<link rel="stylesheet" href="<?= base_url."assets/dist/css/AdminLTE.min.css"; ?>">
		<!-- AdminLTE Skins. Choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
		<link rel="stylesheet" href="<?= base_url."assets/dist/css/skins/_all-skins.min.css"; ?>">

		<link rel="stylesheet" type="text/css" href="<?= base_url."assets/plugins/sweet-alert/sweet-alert.min.css"; ?>">
		<link rel="stylesheet" type="text/css" href="<?= base_url."assets/plugins/alertifyjs/css/alertify.min.css"; ?>">
		<link rel="stylesheet" type="text/css" href="<?= base_url."assets/plugins/alertifyjs/css/themes/bootstrap.min.css"; ?>">
		
		<style type="text/css">
			legend{
				font-size: 15px;
			}
			/*.rp{
				background-color: #dd4b39;
				border-color: #d73925;
			}*/

			/* uplaod foto v2 */
			.image-preview-input{
				position: relative;
				overflow: hidden;
				margin: 0px;    
			    color: #333;
			    background-color: #fff;
			    border-color: #ccc;
			}
			.image-preview-input input[type=file] {
				position: absolute;
				top: 0;
				right: 0;
				margin: 0;
				padding: 0;
				font-size: 20px;
				cursor: pointer;
				opacity: 0;
				filter: alpha(opacity=0);
			}
			.image-preview-input-title {
			    margin-left:2px;
			}
		</style>
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

	<!-- end CSS -->