<?php
    Defined("BASE_PATH") or die("Dilarang Mengakses File Secara Langsung");

?>

<!-- Main Footer -->
<footer class="main-footer">
	<!-- To the right -->
	<div class="pull-right hidden-xs">
  		<?= version; ?>
	</div>

	<!-- Default to the left -->
	<strong>Sistem Informasi Zaco Hijab | Copyright &copy; <?php echo date("Y"); ?> <a href="javascript:;">Zaco Hijab</a>.</strong> All rights reserved.
	
</footer>